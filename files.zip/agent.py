"""
William — a group-conversation voice agent.

One microphone, several people talking. Speechmatics diarization tags each
utterance with a speaker ID; William stays quiet and listens until either:

  1. someone says his name, or
  2. the room goes quiet for IDLE_REPLY_SECONDS.

Run locally:   python agent.py console
"""

from __future__ import annotations

import asyncio
import logging
import os
import re
import time

from dotenv import load_dotenv
from livekit import agents
from livekit.agents import (
    Agent,
    AgentSession,
    JobContext,
    RoomInputOptions,
    StopResponse,
    llm,
)
from livekit.plugins import openai, silero, speechmatics

load_dotenv(".env.local")
logger = logging.getLogger("william")


# ═══════════════════════════════════════════════════════════════════════
#  PROMPT — this is the part to grow.
# ═══════════════════════════════════════════════════════════════════════

SYSTEM_PROMPT = """\
You are William, a voice participant in a conversation between several people
who are sharing a single microphone in the same room.

The transcript you receive is speaker-tagged, like this:

    [Speaker S1] I think we should push the deadline.
    [Speaker S2] Disagree — the client already moved it twice.

Those tags are the diarization system's labels, not names. Track who holds
which position across the conversation. If someone states their name, start
using it.

How to behave:
- You are a participant, not a narrator. Never summarize what was just said
  back to the group unless asked.
- Keep replies to two or three sentences. This is speech, not prose.
- Address people by their speaker label or name when responding to a specific
  point ("S2, on the client timeline —").
- When you were not directly addressed and are speaking into a lull, only
  contribute if you have something concrete: a fact, a correction, an option
  nobody raised. Otherwise reply with the single word SKIP.
"""

# Anything matching this counts as the group addressing William directly.
# Keep it tight — a loose pattern fires on ordinary speech.
WAKE_PATTERN = re.compile(r"\b(william|will iam|willem)\b", re.IGNORECASE)

# Seconds of room silence after which William may volunteer something.
IDLE_REPLY_SECONDS = 5.0

# Reply exactly equal to this (from the prompt above) is swallowed, not spoken.
SKIP_TOKEN = "SKIP"


# ═══════════════════════════════════════════════════════════════════════
#  Agent
# ═══════════════════════════════════════════════════════════════════════


class William(Agent):
    def __init__(self) -> None:
        super().__init__(instructions=SYSTEM_PROMPT)
        self._buffer: list[str] = []          # group talk William hasn't answered
        self._last_speech = time.monotonic()
        self._idle_task: asyncio.Task | None = None
        self._busy = False

    async def on_enter(self) -> None:
        self._idle_task = asyncio.create_task(self._watch_for_silence())

    async def on_exit(self) -> None:
        if self._idle_task:
            self._idle_task.cancel()

    async def on_user_turn_completed(
        self, turn_ctx: llm.ChatContext, new_message: llm.ChatMessage
    ) -> None:
        """Runs at the end of every human turn, before any reply is generated.

        We raise StopResponse unconditionally, which suppresses the framework's
        automatic answer. Every word William speaks is triggered explicitly in
        _respond() instead — that's what turns him from a call-and-response
        assistant into something that sits in a group and waits.
        """
        text = (new_message.text_content or "").strip()
        self._last_speech = time.monotonic()

        if not text:
            raise StopResponse()

        self._buffer.append(text)
        logger.debug("heard: %s", text)

        if WAKE_PATTERN.search(text):
            asyncio.create_task(self._respond(reason="addressed"))

        raise StopResponse()

    async def _watch_for_silence(self) -> None:
        """Fires a reply once the room has been quiet long enough."""
        while True:
            await asyncio.sleep(0.25)
            if self._busy or not self._buffer:
                continue
            if time.monotonic() - self._last_speech >= IDLE_REPLY_SECONDS:
                await self._respond(reason="silence")

    async def _respond(self, reason: str) -> None:
        if self._busy or not self._buffer:
            return
        self._busy = True
        try:
            transcript = "\n".join(self._buffer)
            self._buffer.clear()
            logger.info("responding (%s):\n%s", reason, transcript)

            if reason == "addressed":
                instructions = (
                    "You were addressed by name. Respond to what was asked of you."
                )
            else:
                instructions = (
                    "The room has fallen silent. You were not addressed. "
                    f"Contribute only if you have something concrete to add; "
                    f"otherwise reply with exactly {SKIP_TOKEN}."
                )

            handle = self.session.generate_reply(
                user_input=transcript,
                instructions=instructions,
            )
            await handle.wait_for_playout()
        finally:
            # Reset the clock so a silence-triggered reply doesn't immediately
            # retrigger itself.
            self._last_speech = time.monotonic()
            self._busy = False


# ═══════════════════════════════════════════════════════════════════════
#  Session
# ═══════════════════════════════════════════════════════════════════════


async def entrypoint(ctx: JobContext) -> None:
    await ctx.connect()

    session = AgentSession(
        stt=speechmatics.STT(
            enable_diarization=True,
            speaker_active_format="[Speaker {speaker_id}] {text}",
            # max_speakers=4,
            #
            # Once you know which label is which person, you can pin names:
            #   speakers=[SpeakerIdentifier(label="Josh", speaker_identifiers=[...])]
            # and ignore the agent's own voice with stt.update_speakers(...).
        ),
        # Reads OPENROUTER_API_KEY from the environment. fallback_models is
        # OpenRouter's own routing, not a LiveKit feature — worth having when a
        # provider hiccup would otherwise stall a live conversation.
        llm=openai.LLM.with_openrouter(
            model=os.getenv("LLM_MODEL", "anthropic/claude-sonnet-4.5"),
            fallback_models=["openai/gpt-4o"],
        ),
        tts=speechmatics.TTS(),
        vad=silero.VAD.load(),
        # Endpointing is deliberately slack — in a group, short pauses are
        # people thinking, not turn boundaries.
        min_endpointing_delay=0.8,
        max_endpointing_delay=6.0,
    )

    await session.start(
        agent=William(),
        room=ctx.room,
        room_input_options=RoomInputOptions(),
    )
    # No opening greeting on purpose: William waits to be invited in.


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    agents.cli.run_app(agents.WorkerOptions(entrypoint_fnc=entrypoint))
